import { getHome, searchSongs } from '../music.js';
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    const q = req.query.q;
    if (q) return res.status(200).json({ success: true, results: await searchSongs(q) });
    return res.status(200).json({ success: true, ...(await getHome()) });
  } catch (err) { return res.status(500).json({ success: false, message: err.message }); }
}
