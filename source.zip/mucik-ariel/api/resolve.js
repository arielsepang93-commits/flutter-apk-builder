import { resolveYoutube } from '../music.js';
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  if (req.method === 'OPTIONS') return res.status(204).end();
  const q = req.query.q;
  if (!q) return res.status(400).json({ success: false, message: 'q wajib' });
  try {
    const videoId = await resolveYoutube(q);
    return res.status(200).json({ success: true, videoId });
  } catch (err) { return res.status(500).json({ success: false, message: err.message }); }
}
