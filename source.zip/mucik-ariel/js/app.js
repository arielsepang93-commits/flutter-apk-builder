// ============================================================
// MUCIK ARIEL — app.js FINAL
// ============================================================

var contentEl = document.getElementById('content');
var searchInput = document.getElementById('searchInput');
var searchTimer = null;
var currentTrack = null;
var ytPlayer = null;
var ytReady = false;
var progressTimer = null;
var isRepeat = false;
var isFav = false;
var playToken = 0;

var GENRES = [
  { name: 'POP INDO',  color: '#ec4899', icon: '<path d="M12 15a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3z"/><path d="M19 11a7 7 0 0 1-14 0"/><line x1="12" y1="18" x2="12" y2="22"/><line x1="8" y1="22" x2="16" y2="22"/>' },
  { name: 'DANGDUT',   color: '#dc2626', icon: '<ellipse cx="12" cy="14" rx="9" ry="5"/><line x1="4" y1="14" x2="4" y2="18"/><line x1="20" y1="14" x2="20" y2="18"/><line x1="9" y1="9" x2="9" y2="6"/><line x1="15" y1="9" x2="15" y2="6"/>' },
  { name: 'ROCK INDO', color: '#7c3aed', icon: '<path d="M20 4L14 10"/><circle cx="10" cy="14" r="6"/><circle cx="10" cy="14" r="2"/><path d="M10 8v-4"/>' },
  { name: 'INDIE',     color: '#0891b2', icon: '<path d="M11 20A7 7 0 0 1 11 6c3-3 7-3 10-3-1 3-1 7-4 10a7 7 0 0 1-6 7z"/><line x1="8" y1="22" x2="20" y2="10"/>' },
  { name: 'KERONCONG', color: '#f59e0b', icon: '<path d="M12 6v12"/><ellipse cx="12" cy="9" rx="3" ry="4"/><ellipse cx="12" cy="16" rx="4" ry="3"/><line x1="12" y1="2" x2="12" y2="4"/>' },
  { name: 'EDM INDO',  color: '#16a34a', icon: '<rect x="3" y="4" width="18" height="14" rx="2"/><line x1="8" y1="10" x2="8" y2="14"/><line x1="12" y1="10" x2="12" y2="14"/><line x1="16" y1="10" x2="16" y2="14"/><line x1="5" y1="21" x2="19" y2="21"/>' }
];

function esc(s){
  if (s == null) s = '';
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function showToast(msg){
  var t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(function(){ t.classList.remove('show'); }, 1800);
}

function showMiniLoading(on){
  var el = document.getElementById('miniLoading');
  if (el) el.classList.toggle('show', on);
}

// ============================================================
// HOME
// ============================================================
async function loadHome(){
  contentEl.innerHTML = '<div class="skeleton skeleton-hero"></div><div class="skeleton skeleton-row"></div><div class="skeleton skeleton-row"></div>';
  try {
    var res = await fetch('/api/home');
    var data = await res.json();
    if (!data.success) throw new Error(data.message || 'Gagal memuat');
    renderHome(data);
  } catch(err){
    renderError(err.message);
  }
}

function renderHome(data){
  var html = '';
  if (data.hero) html += renderHero(data.hero);
  if (data.trending && data.trending.length){
    html += '<section class="section"><div class="section-head"><h2 class="section-title">DEV ARIEL</h2></div><div class="hscroll">';
    data.trending.forEach(function(t){ html += renderTrackCard(t); });
    html += '</div></section>';
  }
  if (data.charts && data.charts.length){
    html += '<section class="section"><div class="section-head"><h2 class="section-title">DEV ARIEL</h2></div><div class="chart-list">';
    data.charts.forEach(function(t, i){ html += renderChartItem(t, i); });
    html += '</div></section>';
  }
  if (data.dangdut && data.dangdut.length){
    html += '<section class="section"><div class="section-head"><h2 class="section-title">DEV ARIEL</h2></div><div class="hscroll">';
    data.dangdut.forEach(function(t){ html += renderTrackCard(t); });
    html += '</div></section>';
  }
  if (data.fresh && data.fresh.length){
    html += '<section class="section"><div class="section-head"><h2 class="section-title">DEV ARIEL</h2></div><div class="hscroll">';
    data.fresh.forEach(function(t){ html += renderTrackCard(t); });
    html += '</div></section>';
  }
  html += '<section class="section"><div class="section-head"><h2 class="section-title">DEV ARIEL</h2></div><div class="grid-2">';
  GENRES.forEach(function(g){
    html += '<div class="genre-tile" style="background:' + g.color + '" onclick="searchGenre(\'' + g.name + '\')"><div class="genre-name">' + g.name + '</div><div class="genre-icon"><svg viewBox="0 0 24 24">' + g.icon + '</svg></div></div>';
  });
  html += '</div></section>';
  contentEl.innerHTML = html;
}

function trackAttr(t){
  return JSON.stringify(t).replace(/'/g, "&#39;").replace(/</g, '&lt;');
}

function renderHero(t){
  return '<div class="hero" onclick=\'playTrack(' + trackAttr(t) + ')\'>' +
    '<img class="hero-art" src="' + esc(t.art) + '" onerror="this.style.background=\'#fff\';this.src=\'\'">' +
    '<div class="hero-info"><span class="hero-tag">FEATURED</span><div class="hero-title">' + esc(t.title) + '</div><div class="hero-artist">' + esc(t.artist) + '</div></div></div>';
}

function renderTrackCard(t){
  return '<div class="track-card" onclick=\'playTrack(' + trackAttr(t) + ')\'>' +
    '<div class="track-card-art-wrap">' +
      '<img class="track-card-art" src="' + esc(t.art) + '" loading="lazy" onerror="this.style.background=\'#eee\';this.src=\'\'">' +
      '<div class="track-card-play"><svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg></div></div>' +
    '<div class="track-card-title">' + esc(t.title) + '</div>' +
    '<div class="track-card-artist">' + esc(t.artist) + '</div></div>';
}

function renderChartItem(t, i){
  return '<div class="chart-item" onclick=\'playTrack(' + trackAttr(t) + ')\'>' +
    '<div class="chart-num">' + (i + 1) + '</div>' +
    '<img class="chart-art" src="' + esc(t.art) + '" loading="lazy" onerror="this.style.background=\'#eee\';this.src=\'\'">' +
    '<div class="chart-info"><div class="chart-title">' + esc(t.title) + '</div><div class="chart-artist">' + esc(t.artist) + '</div></div>' +
    '<div class="chart-play"><svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg></div></div>';
}

function renderError(msg){
  contentEl.innerHTML = '<div class="err-box"><div class="err-title">OOPS!</div><div class="err-desc">' + esc(msg) + '</div></div>';
}

// SEARCH
searchInput.addEventListener('input', function(){
  clearTimeout(searchTimer);
  var q = searchInput.value.trim();
  searchTimer = setTimeout(function(){
    if (!q) { loadHome(); return; }
    doSearch(q);
  }, 500);
});

async function doSearch(q){
  contentEl.innerHTML = '<div class="skeleton skeleton-hero"></div>';
  try {
    var res = await fetch('/api/home?q=' + encodeURIComponent(q));
    var data = await res.json();
    if (!data.success) throw new Error(data.message || 'Gagal');
    var results = data.results || [];
    if (!results.length){
      contentEl.innerHTML = '<div class="err-box"><div class="err-title">KOSONG</div><div class="err-desc">Tidak ada hasil untuk "' + esc(q) + '"</div></div>';
      return;
    }
    var html = '<section class="section"><div class="section-head"><h2 class="section-title">DEV ARIEL</h2></div><div class="chart-list">';
    results.forEach(function(t, i){ html += renderChartItem(t, i); });
    html += '</div></section>';
    contentEl.innerHTML = html;
  } catch(err){
    renderError(err.message);
  }
}

function searchGenre(name){
  searchInput.value = name;
  doSearch(name);
}

// ============================================================
// YOUTUBE IFRAME API
// ============================================================
(function loadYT(){
  var tag = document.createElement('script');
  tag.src = 'https://www.youtube.com/iframe_api';
  document.head.appendChild(tag);
})();

window.onYouTubeIframeAPIReady = function(){
  ytReady = true;
};

// Buat YT player baru — dipanggil tiap ganti lagu
function createYTPlayer(videoId){
  var holder = document.getElementById('ytHolder');
  if (!holder) return null;
  holder.innerHTML = '<div id="ytPlayer"></div>';
  return new YT.Player('ytPlayer', {
    height: '1',
    width: '1',
    videoId: videoId,
    playerVars: {
      autoplay: 1,
      controls: 0,
      modestbranding: 1,
      rel: 0,
      playsinline: 1,
      disablekb: 1,
      fs: 0
    },
    events: {
      onReady: function(e){
        try { e.target.unMute(); e.target.setVolume(100); } catch(err) {}
        e.target.playVideo();
      },
      onStateChange: onStateChange
    }
  });
}

// Hancurin YT player — lagu lama mati TOTAL
function destroyYTPlayer(){
  if (ytPlayer){
    try { ytPlayer.stopVideo(); } catch(e) {}
    try { ytPlayer.destroy(); } catch(e) {}
    ytPlayer = null;
  }
  var holder = document.getElementById('ytHolder');
  if (holder) holder.innerHTML = '<div id="ytPlayer"></div>';
}

function onStateChange(e){
  if (!window.YT) return;
  var s = window.YT.PlayerState;
  if (e.data === s.PLAYING){
    showMiniLoading(false);
    document.getElementById('fpIcon').innerHTML = '<path d="M6 5h4v14H6zM14 5h4v14h-4z"/>';
    document.getElementById('mpIcon').innerHTML = '<path d="M6 5h4v14H6zM14 5h4v14h-4z"/>';
    startProgress();
    if (navigator.mediaSession) navigator.mediaSession.playbackState = 'playing';
  } else if (e.data === s.PAUSED){
    document.getElementById('fpIcon').innerHTML = '<path d="M8 5v14l11-7z"/>';
    document.getElementById('mpIcon').innerHTML = '<path d="M8 5v14l11-7z"/>';
    stopProgress();
    if (navigator.mediaSession) navigator.mediaSession.playbackState = 'paused';
  } else if (e.data === s.ENDED){
    if (isRepeat && ytPlayer){ ytPlayer.seekTo(0); ytPlayer.playVideo(); }
    else {
      document.getElementById('fpIcon').innerHTML = '<path d="M8 5v14l11-7z"/>';
      document.getElementById('mpIcon').innerHTML = '<path d="M8 5v14l11-7z"/>';
      stopProgress();
    }
  }
}

function startProgress(){ stopProgress(); progressTimer = setInterval(updateProgress, 500); }
function stopProgress(){ if (progressTimer) clearInterval(progressTimer); }

function updateProgress(){
  if (!ytPlayer || !ytPlayer.getDuration) return;
  var d = ytPlayer.getDuration();
  var c = ytPlayer.getCurrentTime();
  if (d > 0){
    var pct = (c/d)*100;
    document.getElementById('fpProgress').style.width = pct + '%';
    document.getElementById('mpProgress').style.width = pct + '%';
    document.getElementById('fpCurrent').textContent = fmt(c);
    document.getElementById('fpDuration').textContent = fmt(d);
  }
}

function fmt(s){
  s = Math.floor(s || 0);
  var m = Math.floor(s/60);
  var r = s % 60;
  return m + ':' + String(r).padStart(2,'0');
}

// ============================================================
// PLAY TRACK — HANCURIN TOTAL LAGU LAMA
// ============================================================
function playTrack(t){
  playToken++;
  var myToken = playToken;

  // 1. MATIKAN LAGU LAMA TOTAL
  destroyYTPlayer();
  stopProgress();

  // 2. RESET UI
  document.getElementById('mpProgress').style.width = '0%';
  document.getElementById('fpProgress').style.width = '0%';
  document.getElementById('fpCurrent').textContent = '0:00';
  document.getElementById('fpDuration').textContent = '0:00';

  // 3. SET LAGU BARU
  currentTrack = t;
  document.getElementById('mpArt').src = t.art || '';
  document.getElementById('mpTitle').textContent = t.title || '-';
  document.getElementById('mpArtist').textContent = t.artist || '-';
  document.getElementById('mpBar').classList.add('show');
  document.getElementById('fpArt').src = t.art || '';
  document.getElementById('fpTitle').textContent = t.title || '-';
  document.getElementById('fpArtist').textContent = t.artist || '-';
  document.title = (t.title || 'Mucik Ariel') + ' — Mucik Ariel';
  updateMediaSession(t);
  showMiniLoading(true);

  // 4. CARI VIDEO ID
  var query = (t.title || '') + ' ' + (t.artist || '') + ' audio';
  fetch('/api/resolve?q=' + encodeURIComponent(query))
    .then(function(r){ return r.json(); })
    .then(function(d){
      if (myToken !== playToken) return;
      if (!d || !d.success || !d.videoId){
        showMiniLoading(false);
        showToast('Lagu tidak dapat diputar');
        return;
      }
      // 5. BIKIN PLAYER BARU
      ytPlayer = createYTPlayer(d.videoId);
    })
    .catch(function(){
      if (myToken !== playToken) return;
      showMiniLoading(false);
      showToast('Error memuat lagu');
    });
}

// ============================================================
// OVERLAY
// ============================================================
function openFullPlayer(){
  document.getElementById('fpOverlay').classList.add('show');
  document.body.style.overflow = 'hidden';
}

function closeFullPlayer(){
  document.getElementById('fpOverlay').classList.remove('show');
  document.body.style.overflow = '';
}

// ============================================================
// CONTROLS
// ============================================================
function togglePlay(){
  if (!ytPlayer || !ytPlayer.getPlayerState) return;
  var s = ytPlayer.getPlayerState();
  if (s === 1) ytPlayer.pauseVideo();
  else ytPlayer.playVideo();
}

function seekBy(sec){
  if (!ytPlayer || !ytPlayer.getCurrentTime) return;
  var c = ytPlayer.getCurrentTime();
  var d = ytPlayer.getDuration() || 0;
  var n = Math.max(0, Math.min(d, c + sec));
  ytPlayer.seekTo(n, true);
}

function seekTo(e){
  var bar = document.getElementById('fpProgressBar');
  var rect = bar.getBoundingClientRect();
  var pct = (e.clientX - rect.left) / rect.width;
  if (!ytPlayer || !ytPlayer.getDuration) return;
  var d = ytPlayer.getDuration();
  ytPlayer.seekTo(pct * d, true);
}

function toggleRepeat(){
  isRepeat = !isRepeat;
  document.getElementById('fpRepeat').classList.toggle('active', isRepeat);
  showToast(isRepeat ? 'Repeat ON' : 'Repeat OFF');
}

function toggleFav(){
  isFav = !isFav;
  document.getElementById('fpHearth').classList.toggle('active', isFav);
  showToast(isFav ? 'Ditambah ke favorit' : 'Dihapus dari favorit');
}

// ============================================================
// MEDIA SESSION
// ============================================================
function updateMediaSession(t){
  if ('mediaSession' in navigator && t){
    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: t.title || 'Unknown',
        artist: t.artist || 'Unknown',
        album: 'Mucik Ariel',
        artwork: t.art ? [{ src: t.art, sizes: '512x512', type: 'image/jpeg' }] : []
      });
      navigator.mediaSession.setActionHandler('play', function(){ ytPlayer && ytPlayer.playVideo(); });
      navigator.mediaSession.setActionHandler('pause', function(){ ytPlayer && ytPlayer.pauseVideo(); });
      navigator.mediaSession.setActionHandler('seekbackward', function(){ seekBy(-10); });
      navigator.mediaSession.setActionHandler('seekforward', function(){ seekBy(10); });
    } catch(e) {}
  }
}

// ============================================================
// SERVICE WORKER
// ============================================================
if ('serviceWorker' in navigator){
  window.addEventListener('load', function(){
    navigator.serviceWorker.register('/sw.js').catch(function(){});
  });
}

// ============================================================
// INIT
// ============================================================
loadHome();
