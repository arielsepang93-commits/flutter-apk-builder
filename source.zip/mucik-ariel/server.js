import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { getHome, searchSongs, resolveYoutube } from './music.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = 3001;
const MIME = { '.html':'text/html; charset=utf-8', '.css':'text/css; charset=utf-8', '.js':'application/javascript; charset=utf-8', '.json':'application/json; charset=utf-8', '.svg':'image/svg+xml', '.png':'image/png', '.jpg':'image/jpeg', '.webp':'image/webp' };

function getLanIp() {
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] || []) {
      if (net.family === 'IPv4' && !net.internal) return net.address;
    }
  }
  return 'localhost';
}

const server = http.createServer(async (req, res) => {
  const urlObj = new URL(req.url, 'http://' + (req.headers.host || 'localhost'));
  const pathname = urlObj.pathname;
  res.setHeader('Access-Control-Allow-Origin', '*');
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

  if (pathname === '/api/home') {
    try {
      const q = urlObj.searchParams.get('q');
      const data = q ? { success: true, results: await searchSongs(q) } : { success: true, ...(await getHome()) };
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify(data));
    } catch (err) { res.writeHead(500, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ success: false, message: err.message })); }
  }

  if (pathname === '/api/resolve') {
    try {
      const q = urlObj.searchParams.get('q');
      if (!q) { res.writeHead(400); return res.end(JSON.stringify({ success: false, message: 'q wajib' })); }
      const videoId = await resolveYoutube(q);
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ success: true, videoId }));
    } catch (err) { res.writeHead(500, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ success: false, message: err.message })); }
  }

  let fp = pathname === '/' ? '/index.html' : pathname;
  const full = path.join(__dirname, fp);
  if (!full.startsWith(__dirname)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(full, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(full).toLowerCase()] || 'application/octet-stream' });
    res.end(data);
  });
});

server.listen(PORT, '0.0.0.0', () => {
  const ip = getLanIp();
  console.log('http://localhost:' + PORT);
  console.log('http://' + ip + ':' + PORT);
});
