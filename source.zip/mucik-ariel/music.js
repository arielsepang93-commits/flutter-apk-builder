const cache = new Map();
const CACHE_TTL = 5 * 60 * 1000;

async function cachedFetch(url, opts) {
  const now = Date.now();
  const hit = cache.get(url);
  if (hit && now - hit.t < CACHE_TTL) return hit.v;
  const res = await fetch(url, opts);
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const data = await res.json();
  cache.set(url, { t: now, v: data });
  return data;
}

function bigArt(url) {
  if (!url) return '';
  return url.replace(/100x100bb/, '600x600bb');
}

function normalize(track) {
  if (!track) return null;
  return {
    id: track.trackId,
    title: track.trackName,
    artist: track.artistName,
    album: track.collectionName,
    art: bigArt(track.artworkUrl100 || track.artworkUrl60),
    preview: track.previewUrl || '',
    duration: track.trackTimeMillis || 0,
    genre: track.primaryGenreName || '',
    url: track.trackViewUrl || ''
  };
}

async function search(term, limit, country) {
  const url = 'https://itunes.apple.com/search?term=' +
    encodeURIComponent(term) +
    '&media=music&entity=song&limit=' + (limit || 12) +
    '&country=' + (country || 'id');
  const data = await cachedFetch(url, {
    headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json' },
    signal: AbortSignal.timeout(15000)
  });
  return (data.results || []).map(normalize).filter(Boolean);
}

async function topSongsIndonesia() {
  try {
    const data = await cachedFetch(
      'https://rss.applemarketingtools.com/api/v2/id/music/most-played/25/songs.json',
      { headers: { 'User-Agent': 'Mozilla/5.0' }, signal: AbortSignal.timeout(15000) }
    );
    const feed = (data.feed && data.feed.results) || [];
    return feed.map(item => ({
      id: item.id,
      title: item.name,
      artist: item.artistName,
      album: item.name,
      art: bigArt(item.artworkUrl100),
      preview: '',
      duration: 0,
      genre: (item.genres && item.genres[0] && item.genres[0].name) || '',
      url: item.url
    }));
  } catch { return []; }
}

export async function getHome() {
  const [heroArr, trending, charts, dangdut, popIndo] = await Promise.all([
    search('top hits indonesia 2024', 1).catch(() => []),
    search('lagu pop indonesia terbaru', 10).catch(() => []),
    topSongsIndonesia().catch(() => []),
    search('dangdut koplo', 8).catch(() => []),
    search('indie indonesia', 8).catch(() => [])
  ]);

  const hero = heroArr[0] || trending[0] || charts[0] || null;

  return {
    hero,
    trending,
    charts: charts.slice(0, 20),
    fresh: popIndo,
    dangdut
  };
}

export async function searchSongs(keyword) {
  if (!keyword || !keyword.trim()) return [];
  return search(keyword.trim(), 25, 'id');
}

async function tryPiped(query, base) {
  const r = await fetch(base + '/search?q=' + encodeURIComponent(query) + '&filter=music_songs', {
    headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json' },
    signal: AbortSignal.timeout(7000)
  });
  if (!r.ok) throw new Error('HTTP');
  const data = await r.json();
  const items = data.items || [];
  for (const it of items) {
    const m = (it.url || '').match(/[?&]v=([A-Za-z0-9_-]{11})/);
    if (m) return m[1];
  }
  return null;
}

async function tryInvidious(query, base) {
  const r = await fetch(base + '/api/v1/search?q=' + encodeURIComponent(query) + '&type=video', {
    headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json' },
    signal: AbortSignal.timeout(7000)
  });
  if (!r.ok) throw new Error('HTTP');
  const arr = await r.json();
  if (Array.isArray(arr)) {
    for (const it of arr) if (it && it.videoId) return it.videoId;
  }
  return null;
}

async function tryScrapeYt(query) {
  const r = await fetch('https://www.youtube.com/results?search_query=' + encodeURIComponent(query) + '&sp=EgIQAQ%253D%253D', {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/128.0.0.0 Safari/537.36',
      'Accept-Language': 'id-ID,id;q=0.9,en;q=0.8'
    },
    signal: AbortSignal.timeout(10000)
  });
  if (!r.ok) throw new Error('HTTP');
  const html = await r.text();
  const m = html.match(/"videoId":"([A-Za-z0-9_-]{11})"/);
  return m ? m[1] : null;
}

export async function resolveYoutube(query) {
  if (!query) return null;
  const piped = ['https://pipedapi.kavin.rocks', 'https://pipedapi.adminforge.de', 'https://api.piped.yt'];
  const inv = ['https://inv.nadeko.net', 'https://yewtu.be', 'https://invidious.nerdvpn.de'];

  for (const b of piped) { try { const id = await tryPiped(query, b); if (id) return id; } catch {} }
  for (const b of inv)   { try { const id = await tryInvidious(query, b); if (id) return id; } catch {} }
  try { return await tryScrapeYt(query); } catch {}
  return null;
}
