// ============================================================
// MUCIK ARIEL — Service Worker v2
// ============================================================
const CACHE = 'mucik-ariel-v99';
const ASSETS = ['/', '/index.html', '/manifest.json', '/css/style.css', '/js/app.js'];

self.addEventListener('install', function(e){
  e.waitUntil(
    caches.open(CACHE).then(function(c){
      return c.addAll(ASSETS).catch(function(){});
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', function(e){
  e.waitUntil(
    caches.keys().then(function(keys){
      return Promise.all(
        keys.filter(function(k){ return k !== CACHE; })
            .map(function(k){ return caches.delete(k); })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', function(e){
  var url = new URL(e.request.url);
  // jangan cache API dan halaman player lama
  if (url.pathname.startsWith('/api/')) return;
  if (url.pathname === '/player.html') {
    e.respondWith(new Response('', { status: 404 }));
    return;
  }
  if (url.origin !== location.origin) return;

  e.respondWith(
    caches.match(e.request).then(function(cached){
      return cached || fetch(e.request).then(function(res){
        if (res && res.status === 200 && res.type === 'basic'){
          var clone = res.clone();
          caches.open(CACHE).then(function(c){ c.put(e.request, clone); });
        }
        return res;
      }).catch(function(){ return cached; });
    })
  );
});
